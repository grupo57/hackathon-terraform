<?php

return [
    App\Infrastructure\Providers\AppServiceProvider::class,
];
