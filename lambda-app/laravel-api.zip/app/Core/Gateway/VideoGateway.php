<?php

namespace App\Core\Gateway;

interface VideoGateway {}